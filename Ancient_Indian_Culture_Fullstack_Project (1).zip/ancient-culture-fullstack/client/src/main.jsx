import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Save, Pencil, Check, Trash2, Video, Moon, Sun, Database, RefreshCw } from 'lucide-react';
import './research.css';
import './app.css';

const TOPICS = [
  {id:'games', name:'Games'}, {id:'dance',name:'Dance'}, {id:'music',name:'Music'},
  {id:'festivals',name:'Festivals'}, {id:'drawing',name:'Drawing and painting'}
];
const API = '/api';
function videoEmbed(url) {
  if (!url) return null;
  let m = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([\w-]{11})/);
  if (m) return {type:'iframe',src:`https://www.youtube-nocookie.com/embed/${m[1]}`};
  m = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
  if (m) return {type:'iframe',src:`https://player.vimeo.com/video/${m[1]}`};
  if (/\.mp4(?:\?|$)|\.webm(?:\?|$)/i.test(url)) return {type:'video',src:url};
  return null;
}
function App(){
  const [content,setContent]=useState(''); const [videos,setVideos]=useState({});
  const [editing,setEditing]=useState(false); const [busy,setBusy]=useState(true);
  const [saving,setSaving]=useState(false); const [status,setStatus]=useState('Loading research and database…');
  const [dark,setDark]=useState(false); const [videoTopic,setVideoTopic]=useState('games'); const [videoUrl,setVideoUrl]=useState('');
  const [apiState,setApiState]=useState('Checking backend…');
  async function load(){
    setBusy(true);
    try{
      const [c,v,h]=await Promise.all([fetch(`${API}/content`),fetch(`${API}/videos`),fetch(`${API}/health`)]);
      if(!c.ok||!v.ok||!h.ok) throw new Error('API request failed');
      const cd=await c.json(), vd=await v.json(); setContent(cd.html);
      const map={}; vd.forEach(x=>map[x.topic]=x.url); setVideos(map); setApiState('Backend connected'); setStatus('Research loaded from the database.');
    }catch(e){setApiState('Backend not connected');setStatus('Could not connect to the database. Start the backend using the README instructions.');}
    finally{setBusy(false);}
  }
  useEffect(()=>{load();},[]);
  useEffect(()=>{
    if(!content) return;
    const root=document.getElementById('research-content');
    if(!root) return;
    root.querySelectorAll('[data-k]').forEach(el=>{el.contentEditable=editing?'true':'false';el.spellcheck=editing;});
    root.classList.toggle('editing',editing);
  },[content,editing]);
  async function saveContent(){
    const root=document.getElementById('research-content'); if(!root)return;
    setSaving(true);
    try{const r=await fetch(`${API}/content`,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({html:root.innerHTML})});const d=await r.json();if(!r.ok)throw new Error(d.error);setContent(root.innerHTML);setStatus('All research edits saved to SQLite database.');setEditing(false);}
    catch(e){setStatus(`Save failed: ${e.message}`);}finally{setSaving(false);}
  }
  async function saveVideo(){
    try{const r=await fetch(`${API}/videos/${videoTopic}`,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:videoUrl})});const d=await r.json();if(!r.ok)throw new Error(d.error);setVideos(x=>({...x,[videoTopic]:videoUrl.trim()}));setStatus(`${videoTopic} video saved in database.`);}
    catch(e){setStatus(e.message);}
  }
  async function removeVideo(topic){
    try{const r=await fetch(`${API}/videos/${topic}`,{method:'DELETE'});if(!r.ok)throw new Error('Could not remove video');setVideos(x=>{const n={...x};delete n[topic];return n;});if(videoTopic===topic)setVideoUrl('');setStatus(`${topic} video removed.`);}
    catch(e){setStatus(e.message);}
  }
  function chooseTopic(t){setVideoTopic(t);setVideoUrl(videos[t]||'');}
  const count=useMemo(()=>Object.keys(videos).length,[videos]);
  return <div className={dark?'app dark':'app'}>
    <div className="projectbar"><div className="projectbrand"><span className="brandmark">✦</span><span>IKS RESEARCH PROJECT</span></div><div className="projectactions"><span className="api-status"><i/> {apiState}</span><button className="iconbtn" onClick={()=>setDark(!dark)} title="Toggle theme">{dark?<Sun size={17}/>:<Moon size={17}/>}</button><button className="iconbtn" onClick={load} title="Reload from database"><RefreshCw size={17}/></button></div></div>
    <div className="toolbar"><div><b>Project workspace</b><small>Ancient Indian Culture · Full-stack web application</small></div><div className="toolbuttons">{editing?<><button className="btn secondary" onClick={()=>{setEditing(false);load();}}>Cancel</button><button className="btn primary" onClick={saveContent} disabled={saving}><Save size={16}/>{saving?'Saving…':'Save changes'}</button></>:<button className="btn primary" onClick={()=>setEditing(true)}><Pencil size={16}/> Edit research</button>}</div></div>
    <div className="statusline" role="status">{busy?'Loading…':status}</div>
    <div id="research-content" className="research-shell" dangerouslySetInnerHTML={{__html:content}} />
    <section className="video-admin" id="video-library"><div className="video-heading"><span className="video-icon"><Video/></span><div><h2>Animated Video Library</h2><p>Add a YouTube, Vimeo or direct MP4/WEBM link for each research topic. Links are stored in the database.</p></div><span className="video-count">{count}/5 added</span></div>
      <div className="video-grid">{TOPICS.map(t=>{const emb=videoEmbed(videos[t.id]);return <article className="video-card" key={t.id}><div className="video-card-title"><h3>{t.name}</h3>{videos[t.id]&&<span className="saved-tag">Saved</span>}</div><div className="video-frame">{emb?(emb.type==='iframe'?<iframe src={emb.src} title={`${t.name} animated video`} allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen/>:<video src={emb.src} controls/>):<div className="empty-video"><Video size={25}/><span>No video added yet</span></div>}</div><div className="video-card-actions"><button className="text-action" onClick={()=>chooseTopic(t.id)}>Use this topic</button>{videos[t.id]&&<button className="text-action danger" onClick={()=>removeVideo(t.id)}><Trash2 size={14}/> Remove</button>}</div></article>})}</div>
      <div className="video-form"><div className="form-title"><Database size={18}/> Manage topic video</div><label>Research topic<select value={videoTopic} onChange={e=>chooseTopic(e.target.value)}>{TOPICS.map(t=><option value={t.id} key={t.id}>{t.name}</option>)}</select></label><label>Video URL<input value={videoUrl} onChange={e=>setVideoUrl(e.target.value)} placeholder="https://www.youtube.com/watch?v=…"/></label><button className="btn primary" onClick={saveVideo} disabled={!videoUrl.trim()}><Save size={16}/> Save video to database</button></div>
    </section>
    <footer className="app-footer">Ancient Indian Culture · Research on games, dance, music, festivals, and drawing and painting in ancient India.</footer>
  </div>
}

createRoot(document.getElementById('root')).render(<App/>);
