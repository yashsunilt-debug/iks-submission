# Ancient Indian Culture — Full-stack End-Semester Project

This project keeps the research text, images, headings, references and topic order from the supplied HTML research website. It adds a React frontend, Node.js/Express REST API, SQLite database, editable research text, and a per-topic video manager.

## Technology stack
- Frontend: React 18, Vite, HTML, CSS, JavaScript
- Backend: Node.js + Express
- Database: SQLite (`better-sqlite3`), SQL tables
- API: REST endpoints using JSON over HTTP
- UI/UX: responsive layout, topic navigation, edit/save controls, dark mode, video cards

## Requirements
Install Node.js LTS (includes npm). Internet is needed for the first installation of npm packages. No separate database server is required; SQLite creates its database automatically.

## Run on Windows (VS Code terminal / PowerShell)
1. Extract this ZIP folder.
2. Open the extracted `ancient-culture-fullstack` folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:

```bash
npm install
npm run install:all
npm run dev
```

5. Open the frontend URL printed by Vite, normally `http://localhost:5173`.
6. Keep both terminal processes running. The API normally runs at `http://localhost:5000`.

## Production build
```bash
npm run build
npm start
```
Then open `http://localhost:5000`.

## API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Check whether backend is running |
| GET | `/api/content` | Get research HTML from database |
| PUT | `/api/content` | Save edited research HTML to database |
| GET | `/api/videos` | Get all saved topic video links |
| PUT | `/api/videos/:topic` | Add/update a topic video URL |
| DELETE | `/api/videos/:topic` | Remove a topic video URL |

Allowed topic values: `games`, `dance`, `music`, `festivals`, `drawing`.

## Database design
### `site_content`
- `id` — primary key (the single main research page uses id 1)
- `html` — saved HTML for the complete research page
- `updated_at` — last update timestamp

### `videos`
- `id` — primary key
- `topic` — unique topic key
- `url` — YouTube, Vimeo, or direct MP4/WEBM link
- `updated_at` — last update timestamp

The database file is created at `server/data/culture.db` after the first server start. The original research is seeded into the database automatically if the content table is empty.

## Important project demonstration
- Click **Edit research**, then edit a paragraph in the research page and click **Save changes**. The React frontend sends a PUT request to Express, and Express saves the HTML in SQLite.
- In **Animated Video Library**, select a topic, paste a video URL and save. The backend stores it in the `videos` table. Reloading the page loads the saved URL from the database.
- Images embedded in the original research HTML are retained. The supplied research page contains its own photographs and references.

## Viva / end-semester explanation
**Frontend:** React is the frontend library used to build the user interface. Components and state manage editing, video forms, loading and status messages.

**Backend:** Node.js runs JavaScript outside the browser. Express creates the server and API routes, validates requests and communicates with SQLite.

**Database:** SQLite is a relational database. SQL commands create tables, insert the initial content, select data, update saved content and delete video records.

**API integration:** React uses `fetch()` to send HTTP requests to the Express API. JSON is used to exchange data. GET reads data, PUT creates/updates data, and DELETE removes a video.

**UI vs UX:** UI is the visible design (colours, typography, cards, navigation and controls). UX is how easily a user can navigate topics, edit content, save changes and add videos.

**Data flow:** User action → React event handler → fetch request → Express route → SQL query → SQLite database → JSON response → React state/UI update.

## Note
This is a local academic demonstration project. It does not include user login, role-based permissions, cloud hosting, or production security. Do not expose it publicly with editing enabled without adding authentication and authorization.
