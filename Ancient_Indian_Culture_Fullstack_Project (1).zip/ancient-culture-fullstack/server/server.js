import express from 'express';
import cors from 'cors';
import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 5000;
app.use(cors());
app.use(express.json({ limit: '15mb' }));

// SQLite database and tables are created automatically on first run.
const db = new Database(path.join(__dirname, 'data', 'culture.db'));
db.pragma('journal_mode = WAL');
db.exec(`
  CREATE TABLE IF NOT EXISTS site_content (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    html TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS videos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    topic TEXT NOT NULL UNIQUE,
    url TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);
const seedPath = path.join(__dirname, 'research-body.html');
const existing = db.prepare('SELECT id FROM site_content WHERE id=1').get();
if (!existing) {
  const original = fs.readFileSync(seedPath, 'utf8');
  db.prepare('INSERT INTO site_content (id, html) VALUES (1, ?)').run(original);
}

app.get('/api/health', (_req, res) => res.json({ status: 'ok', message: 'Ancient Indian Culture API is running' }));
app.get('/api/content', (_req, res) => {
  const row = db.prepare('SELECT html, updated_at FROM site_content WHERE id=1').get();
  res.json(row);
});
app.put('/api/content', (req, res) => {
  const { html } = req.body || {};
  if (typeof html !== 'string' || !html.trim()) return res.status(400).json({ error: 'Valid HTML content is required.' });
  db.prepare(`UPDATE site_content SET html=?, updated_at=CURRENT_TIMESTAMP WHERE id=1`).run(html);
  res.json({ message: 'Research content saved successfully.' });
});
app.get('/api/videos', (_req, res) => res.json(db.prepare('SELECT topic, url, updated_at FROM videos ORDER BY topic').all()));
app.put('/api/videos/:topic', (req, res) => {
  const allowed = ['games', 'dance', 'music', 'festivals', 'drawing'];
  const topic = req.params.topic;
  const url = String(req.body?.url || '').trim();
  if (!allowed.includes(topic)) return res.status(404).json({ error: 'Unknown topic.' });
  const valid = /^https:\/\/(?:www\.)?(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/|vimeo\.com\/|player\.vimeo\.com\/)/i.test(url) || /^https:\/\/[^\s"'<>]+\.(mp4|webm)(\?[^\s"'<>]*)?$/i.test(url);
  if (!valid) return res.status(400).json({ error: 'Use a YouTube, Vimeo or direct HTTPS MP4/WEBM link.' });
  db.prepare(`INSERT INTO videos(topic,url) VALUES(?,?) ON CONFLICT(topic) DO UPDATE SET url=excluded.url, updated_at=CURRENT_TIMESTAMP`).run(topic, url);
  res.json({ message: 'Video saved.', topic, url });
});
app.delete('/api/videos/:topic', (req, res) => {
  db.prepare('DELETE FROM videos WHERE topic=?').run(req.params.topic);
  res.json({ message: 'Video removed.' });
});

const builtClient = path.resolve(__dirname, '../client/dist');
if (fs.existsSync(builtClient)) {
  app.use(express.static(builtClient));
  app.get('*', (_req, res) => res.sendFile(path.join(builtClient, 'index.html')));
}
app.listen(PORT, () => console.log(`API server running at http://localhost:${PORT}`));
